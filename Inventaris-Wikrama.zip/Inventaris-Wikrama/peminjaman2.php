<?php 
	$fun = new OOP();
	$datas = $fun->select("tb_peminjam");

 ?>


<form action="" method="POST">
	<div class="row">
		<div class="col-md-12">
			<div class="col-md-12">
				<div class="tile text-center">
					<h3 class="tile-title">Peminjaman Barang</h3>
					<hr>
					<div class="tile-body">
						<table class="table table-hover table-bordered">
							<thead>
								<tr>
									<th>No</th>
									<th>Kode Peminjam</th>
									<th>Nama Peminjam</th>
									<th>Pilih Peminjam</th>
								</tr>
							</thead>
							<tbody>
								<?php 
									$no = 1;
									foreach ($datas as $pnj) {
								 ?>
								 <tr>
								 	<td><?= $no++ ?></td>
								 	<td><?= $pnj['kd_peminjam']?></td>
								 	<td><?= $pnj['nama']?></td>
								 	<td><a href="?page=pilih&kd=<?= $pnj['kd_peminjam'] ?>" class="btn btn-primary">Pilih</a></td>
								 </tr>
								 <?php } ?>
							</tbody>	
							<tr></tr>
						</table>
					</div>
				</div>				
			</div>
		</div>
	</div>
</form>