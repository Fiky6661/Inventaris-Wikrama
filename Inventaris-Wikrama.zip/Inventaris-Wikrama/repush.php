<?php 
  include 'controller.php';
  $perintah = new OOP();

  $table = "tb_repush";
  $redirect = "?menu=siswa";
  $field = array('kode_kinerja' => $_POST['kode'], 'nama_kinerja' => $_POST['nama'], 'kelompok' => $_POST['kelompok'], 'skor1' => $_POST['skor1'], 'skor2' => $_POST['skor2'], 'skor2' => $_POST['skor2']);

  if (isset($_POST['simpan'])) {
    $perintah->simpan($table, $field, $redirect)
  }
?>
<div class="row">
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Input Reward & Punishment</h3>
            <div class="tile-body">
              <div class="row">
                <div class="col-md-6">
                  <form method="post">
                    <div class="form-group">
                      <label class="control-label">Kode Kinerja</label>
                      <input class="form-control" name="kode" type="text" placeholder="Masukkan Kode Kinerja">
                    </div>
                    <div class="form-group">
                      <label class="control-label">Nama Kinerja</label>
                      <input class="form-control" name="nama" type="text" placeholder="Masukkan Nama Kinerja">
                    </div>
                    <div class="form-group">
                        <label for="exampleSelect1">Kelompok</label>
                        <select class="form-control" name="kelompok" id="exampleSelect1">
                          <option value="H">H</option>
                          <option value="P">P</option>
                        </select>
                    </div>
                    <div class="form-group">
                      <label class="control-label">Skor I</label>
                      <input class="form-control" name="skor1" type="text" placeholder="Masukkan Skor I">
                    </div>
                    <div class="form-group">
                      <label class="control-label">Skor II</label>
                      <input class="form-control" name="skor2" type="text" placeholder="Masukkan Skor II">
                    </div>
                    <div class="form-group">
                      <label class="control-label">Skor III</label>
                      <input class="form-control" name="skor3" type="text" placeholder="Masukkan Skor III">
                    </div>s
                  </div>
              </div>
              
                
            <div class="tile-footer">
              <a class="btn btn-primary" name="simpan" href="#" type="button"><i class="fa fa-fw fa-lg fa-check-circle"></i>Simpan</a>&nbsp;&nbsp;&nbsp;<a class="btn btn-secondary" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Reset</a>
            </div>
            </form>
          </div>
        </div>
        <div class="col-md-12">  
            <div class="tile">
            <h3 class="tile-title">Data Reward</h3>
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>Kode Kinerja</th>
                    <th>Nama Kinerja</th>
                    <th>Skor I</th>
                    <th>Skor II</th>
                    <th>Skor III</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="col-md-12">  
            <div class="tile">
            <h3 class="tile-title">Data Punishment</h3>
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>Kode Kinerja</th>
                    <th>Nama Kinerja</th>
                    <th>Skor I</th>
                    <th>Skor II</th>
                    <th>Skor III</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
          </div>
        
      </div>