<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Laporan</title>
	<link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

	<table class="table table-striped">
		<thead>
			<tr>
				<th>No</th>
				<th>Kode Barang</th>
				<th>Nama Barang</th>
				<th>Jumlah Barang</th>
				<th>Kondisi</th>
				<th>Lokasi</th>
				<th>Ket. Tanggal</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>1</td>
				<td>Modol</td>
				<td>Modol</td>
				<td>Modol</td>
				<td>Modol</td>
				<td>Modol</td>
				<td>Modol</td>
			</tr>
			<tr>
				<td>1</td>
				<td>Modol</td>
				<td>Modol</td>
				<td>Modol</td>
				<td>Modol</td>
				<td>Modol</td>
				<td>Modol</td>
			</tr>
		</tbody>
	</table>
	 <main class="app-content">
      <?php 
        @$page = $_GET['page'];
        switch ($page) {
          case 'dashboard':
            include "dash.php";
          break;
          case 'laporan':
            include "laporan.php";
          break;
          case 'ddg':
            include "rombel.php";
          break;
          case 'dds':
            include "repush.php";
          break;
          case 'absensi':
            include "absensi.php";
          break;
          case 'bkp':
            include "bkp.php";
          break;
          default :
            echo "<script>window.location.href = '?page=dashboard'</script>";
        }

       ?>
    </main>
</body>
</html>