<?php

	date_default_timezone_set("Asia/Jakarta"); 
	$date = date('Y-m-d');
	$table = "tb_barang";
	$id = "id_barang";
	$id = $fun->autokode($table,$id,"ID");
	if (isset($_POST['simpan'])) {

		
		$kode = "KM001";
		$kd_barang = $_POST['kd_barang'];
		$nama = $_POST['nama'];
		$tahun = $_POST['tahun'];
		$sumber = $_POST['sumber'];
		$jumlah = $_POST['jumlah'];
		$tempat = $_POST['tempat'];
		$satuan = $_POST['satuan'];
		$b = $_POST['b'];
		$r = $_POST['r'];
		$rb = $_POST['rb'];
		$h = $_POST['h'];
		$hrga = $_POST['hargasatu'];
		$keterangan = $_POST['keterangan'];

		$table = "tb_barang";
		$values = "'$kode','$kd_barang','$nama','$tahun','$sumber','$jumlah','$tempat','$satuan','$hrga','$b','$r','$rb','$h','$keterangan','$date','$id'";
		$redirect = "dashboard.php?page=idtbg";

		$fun->insert($table,$values,$redirect);
	}

 ?>

<form method="post">
<div class="row">
	<div class="col-md-12">	
		<div class="tile" style="margin-top: 20px;">
			<h3 class="tile-title">Input Data Barang Tata Boga</h3>
			<div class="tile-body">	
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>Kode barang</label>
							<input type="text" name="kd_barang" class="form-control" required="" placeholder="Masukkan Kode Barang">
						</div>
						<div class="form-group">
							<label>Nama Barang</label>
							<input type="text" name="nama" class="form-control" required="" placeholder="Masukkan Nama Barang">
						</div>
						<div class="form-group">
							<label>Tahun Perolehan</label>
							<input class="form-control" id="demoDate" type="text" required="" name="tahun" placeholder="Pilih Tahun Perolehan Barang">
						</div>
						<div class="form-group">
							<label>Sumber Barang</label>
							<input type="text" name="sumber" class="form-control" required="" placeholder="Masukkan Sumber Barang">
						</div>
						<div class="form-group">
							<label>Jumlah Barang</label>
							<input type="Number"  name="jumlah" class="form-control" required="" placeholder="Masukkan Jumlah Barang" validate="">
						</div>
						<div class="form-group">
		                    <label for="exampleSelect1">Tempat Penyimpanan</label>
		                    <select name="tempat" class="form-control" id="exampleSelect1">
		                      <option>1</option>
		                      <option>2</option>
		                      <option>3</option>
		                      <option>4</option>
		                      <option>5</option>
		                    </select>
		                  </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Satuan Barang</label>
							<input type="text" name="satuan" class="form-control" required="" placeholder="Masukkan Satuan Barang">
						</div>
						<div class="form-group">
							<label>Harga Satuan Barang</label>
							<input type="number" name="hargasatu" class="form-control" required="" placeholder="Masukan Harga Satuan Barang">
						</div>
						<label >Keterangan (Kondisi Barang)</label>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label class="text-center">B</label>
									<input type="number" name="b" class="form-control" required="" >
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="text-center">R</label>
									<input type="number" name="r" class="form-control" required="" >
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="text-center">RB</label>
									<input type="number" name="rb" class="form-control" required="" >
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="text-center">H</label>
									<input type="number" name="h" class="form-control" required="" >
								</div>
							</div>
						</div>
						<div class="form-group">
		                    <label for="exampleTextarea">Keterangan</label>
		                    <textarea class="form-control" id="exampleTextarea" rows="5" name="keterangan"></textarea>
		                  </div>
					</div>
				</div>
					

					 <div class="tile-footer">
			            <button type="submit" name="simpan" class="btn btn-primary">Simpan <span class="fa fa-save"></span></button>
			            <a class="btn btn-secondary" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Reset</a>
			        </div>		
			</div>
		</div>
	</div>			
</div>
</form>