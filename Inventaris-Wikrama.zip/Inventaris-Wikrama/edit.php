			<?php
			 $id = $_GET['id'];
			 $datas = $fun->selectWhere("tb_barang","id_barang",$id);
			  

			  if (isset($_POST['editt'])) {
			  $table = "tb_barang";
			  $where = "id_barang";
			  $whereValues = $_POST['id_barang'];
			  $redirect = "?page=dtbg";
			  $kd_barang = $_POST['kd_barang'];
			    $kode = $_POST['kd_barang'];
			    $nama = $_POST['nama'];
			    $tahun = $_POST['tahun'];
			    $sumber = $_POST['sumber'];
			    $jumlah = $_POST['jumlah'];
			    $tempat = $_POST['tempat'];
			    $satuan = $_POST['satuan'];
			    $b = $_POST['baik'];
			    $r = $_POST['rusak'];
			    $rb = $_POST['rusakbe'];
			    $h = $_POST['hilang'];
			    $hrga = $_POST['hargasatu'];
			    $keterangan = $_POST['keterangan'];
			    $values = "kd_barang = '$kode',nama = '$nama',tahun = '$tahun', sumber = '$sumber', jumlah = '$jumlah', tempat =  '$tempat' , satuan = '$satuan' , b = '$b',r = '$r', rb = '$rb', h = '$h', harga = '$hrga' , keterangan = '$keterangan'";

			    $fun->update($table,$values,$where,$whereValues,$redirect);
			}
			 ?>
				
			<form method="post">
			<div class="row">
				<div class="col-md-12">
					<div class="tile">
						<div class="tile-title">
							Edit Data
						</div>
						<div class="tile-body">
							<div class="row">
								<div class="col-md-6">
                                    <div class="form-group">
                                      <label>Id barang</label>
                                      <input type="text" name="id_barang" class="form-control" required="" placeholder="Masukkan Kode Barang" value="<?= $datas['id_barang'] ?>" readonly>
                                    </div>
                                    <div class="form-group">
                                      <label>Kode barang</label>
                                      <input type="text" name="kd_barang" class="form-control" required="" placeholder="Masukkan Kode Barang" value="<?= $datas['kd_barang'] ?>"  >
                                    </div>
                                    <div class="form-group">
                                      <label>Nama Barang</label>
                                      <input type="text" name="nama" class="form-control" required="" placeholder="Masukkan Nama Barang" value="<?= $datas['nama'] ?>" >
                                    </div>
                                    <div class="form-group">
                                      <label>Tahun Perolehan</label>
                                      <input class="form-control" id="demoDate" type="text" required="" name="tahun" placeholder="Pilih Tahun Perolehan Barang" value="<?= $datas['tahun'] ?>">
                                    </div>
                                    <div class="form-group">
                                      <label>Sumber Barang</label>
                                      <input type="text" name="sumber" class="form-control" required="" placeholder="Masukkan Sumber Barang" value="<?= $datas['sumber'] ?>">
                                    </div>
                                    <div class="form-group">
                                                <label for="exampleSelect1">Tempat Penyimpanan</label>
                                                <select name="tempat" class="form-control" id="exampleSelect1">
                                                  <option>1</option>
                                                  <option>2</option>
                                                  <option>3</option>
                                                  <option>4</option>
                                                  <option>5</option>
                                                </select>
                                              </div>
                                    <div class="form-group">
                                      <label>Jumlah Barang</label>
                                      <input type="Number"  name="jumlah" class="form-control" required="" placeholder="Masukkan Jumlah Barang" validate="" value="<?= $datas['jumlah'] ?>">
                                    </div>

                                  </div>
                                  <div class="col-md-6">
                                    <div class="form-group">
                                      <label>Satuan Barang</label>
                                      <input type="text" name="satuan" class="form-control" required="" placeholder="Masukkan Satuan Barang" value="<?= $datas['satuan'] ?>">
                                    </div>
                                    <div class="form-group">
                                      <label>Harga Satuan Barang</label>
                                      <input type="number" name="hargasatu" class="form-control" required="" placeholder="Masukan Harga Satuan Barang" value="<?= $datas['harga'] ?>">
                                    </div>
                                    <label >Keterangan (Kondisi Barang)</label>
                                    <div class="row">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="text-center">B</label>
                                          <input type="number" name="baik" class="form-control" required="" value="<?= $datas['b'] ?>" >
                                        </div>
                                      </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="text-center">R</label>
                                          <input type="number" name="rusak" class="form-control" required="" value="<?= $datas['r'] ?>" >
                                        </div>
                                      </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="text-center">RB</label>
                                          <input type="number" name="rusakbe" class="form-control" required="" value="<?= $datas['rb'] ?>" >
                                        </div>
                                      </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label class="text-center">RB</label>
                                          <input type="number" name="hilang" class="form-control" required="" value="<?= $datas['h'] ?>" >
                                        </div>
                                      </div>	                                     
									</div>
									<div class="form-group">
                                                <label for="exampleTextarea">Keterangan</label>
                                                <textarea class="form-control" name="keterangan" id="exampleTextarea" rows="5" ><?= $datas['keterangan'] ?></textarea>
                                   	  </div>
									<button class="btn btn-danger" name="editt">Simpan</button>
									<button class="btn btn-info" name="kembali">Kembali</button>
								</div>
							</div>
						</div>
					</div>
				</form>