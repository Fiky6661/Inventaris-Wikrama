-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2018 at 04:09 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_logistik`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_approve`
--

CREATE TABLE `tb_approve` (
  `id_approve` int(11) NOT NULL,
  `kd_pinjam` varchar(11) NOT NULL,
  `kd_peminjam` varchar(11) NOT NULL,
  `kd_barang` varchar(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_approve`
--

INSERT INTO `tb_approve` (`id_approve`, `kd_pinjam`, `kd_peminjam`, `kd_barang`, `jumlah`, `tanggal`) VALUES
(61, ' P0001 ', 'SNK001', '9', 1, '2018-04-09'),
(62, ' P0001 ', 'KD004', '1', 1, '2018-04-09');

-- --------------------------------------------------------

--
-- Table structure for table `tb_barang`
--

CREATE TABLE `tb_barang` (
  `kd_milik` varchar(6) NOT NULL,
  `kd_barang` varchar(6) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `tahun` varchar(10) NOT NULL,
  `sumber` varchar(15) NOT NULL,
  `jumlah` int(13) NOT NULL,
  `tempat` varchar(25) NOT NULL,
  `satuan` varchar(15) NOT NULL,
  `harga` int(13) NOT NULL,
  `b` int(13) NOT NULL,
  `r` int(13) NOT NULL,
  `rb` int(13) NOT NULL,
  `h` int(13) NOT NULL,
  `keterangan` text NOT NULL,
  `tanggal_masuk` varchar(25) NOT NULL,
  `id_barang` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_barang`
--

INSERT INTO `tb_barang` (`kd_milik`, `kd_barang`, `nama`, `tahun`, `sumber`, `jumlah`, `tempat`, `satuan`, `harga`, `b`, `r`, `rb`, `h`, `keterangan`, `tanggal_masuk`, `id_barang`) VALUES
('KM001', 'KD004', 'Senok', '04/04/2018', 'Sumber Daya', 90, '1', 'Buah', 5000, 40, 1, 1, 1, '', '2018-04-04', 'ID004'),
('KM001', 'SNK001', 'Senal Jepit', '05/04/2018', 'Sumber Daya', 40, '1', 'Buah', 90000, 16, 9, 9, 1, '', '2018-04-07', 'ID012');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kondisi`
--

CREATE TABLE `tb_kondisi` (
  `kd_kondisi` int(10) NOT NULL,
  `kd_barang` int(10) NOT NULL,
  `b` int(10) NOT NULL,
  `rb` int(10) NOT NULL,
  `r` int(10) NOT NULL,
  `h` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_peminjam`
--

CREATE TABLE `tb_peminjam` (
  `kd_peminjam` varchar(12) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `keterangan` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_peminjam`
--

INSERT INTO `tb_peminjam` (`kd_peminjam`, `nama`, `keterangan`) VALUES
('KP002', 'Fajar Subeki Bau Pisan', 'Naon ath boy'),
('KP003', 'Raka Si Bau', 'cangcut');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pinjam`
--

CREATE TABLE `tb_pinjam` (
  `kd_pinjam` varchar(12) NOT NULL,
  `kd_peminjam` varchar(12) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `nama` varchar(25) NOT NULL,
  `kd_barang` varchar(12) NOT NULL,
  `jumlah` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pinjam`
--

INSERT INTO `tb_pinjam` (`kd_pinjam`, `kd_peminjam`, `status`, `nama`, `kd_barang`, `jumlah`) VALUES
(' P001 ', 'KP002', 0, 'Senal Jepit', 'SNK001', 2),
(' P002 ', 'KP002', 0, 'Senal Jepit', 'SNK001', 2);

--
-- Triggers `tb_pinjam`
--
DELIMITER $$
CREATE TRIGGER `barang_keluar` AFTER INSERT ON `tb_pinjam` FOR EACH ROW UPDATE tb_barang SET
b = b - new.jumlah
WHERE kd_barang = new.kd_barang
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `kembali` AFTER DELETE ON `tb_pinjam` FOR EACH ROW UPDATE tb_barang SET
b = b + OLD.jumlah
WHERE kd_barang = OLD.kd_barang
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_approve`
--
ALTER TABLE `tb_approve`
  ADD PRIMARY KEY (`id_approve`);

--
-- Indexes for table `tb_barang`
--
ALTER TABLE `tb_barang`
  ADD PRIMARY KEY (`kd_barang`);

--
-- Indexes for table `tb_kondisi`
--
ALTER TABLE `tb_kondisi`
  ADD PRIMARY KEY (`kd_kondisi`);

--
-- Indexes for table `tb_peminjam`
--
ALTER TABLE `tb_peminjam`
  ADD PRIMARY KEY (`kd_peminjam`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_approve`
--
ALTER TABLE `tb_approve`
  MODIFY `id_approve` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
