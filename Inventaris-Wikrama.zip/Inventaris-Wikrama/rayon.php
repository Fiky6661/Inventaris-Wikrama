<?php 
  	$perintah = new CRUD();
  	$data = $perintah->select('tb_rayon');
  	$table = "tb_rayon";
  	$autokode = $perintah->autokode("tb_rayon","id_rayon","RY");
  	
  	if (isset($_POST['simpan'])) {
  		@$id_rayon = $perintah->validateHtml($_POST['id_rayon']);
  		@$rayonn   = $perintah->validateHtml($_POST['rayon']);
  		if($rayon = " "){
  			$response = ['response'=>'negative','alert'=>'Lengkapi Field!'];
  		}else{
  			$value = "'$id_rayon','$rayonn'";
  			$response = $perintah->insert($table,$value);
  		}
  	}

?>

<div class="row">
	<div class="col-md-6">	
		<div class="tile">
			<h3 class="tile-title">Input Rayon</h3>
			<div class="tile-body">	
				<form method="post">
					<div class="form-group">
	                    <fieldset disabled="">
	                      <label class="control-label" for="disabledInput">ID Rayon</label>
	                      <input class="form-control" name="id_rayon" type="text" disabled="" value="<?php echo $autokode?>">
	                    </fieldset>
	                  </div>
					<div class="form-group">
						<label>Nama Rayon</label>
						<input type="text" name="rayon" class="form-control" placeholder="Masukkan Nama Rayon">
					</div>
					 <div class="tile-footer">
					 	<button type="submit" class="btn btn-primary" name="simpan">Simpan <i class="fa fa-plus"></i></button>
			       <a class="btn btn-secondary" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Reset</a>
			        </div>
				</form>
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="tile">
			<h3 class="tile-title">Data Rayon</h3>
			<div class="tile-body">
				<table class="table table-hover table-bordered" id="sampleTable">
					<thead>
						<th>No.</th>
                    	<th>ID Rayon</th>
                    	<th>Nama Rayon</th>
                    	<th colspan="2">Aksi</th>
					</thead>
					<tbody>
						<?php 
            				$no = 1;
            				foreach ($data as $rayon) { ?>
            			<tr>
              				<td><?php echo $no; ?></td>
              				<td><?php echo $rayon['id_rayon'] ?></td>
              				<td><?php echo $rayon['rayon'] ?></td>
              				<td><a href="?menu=rayon&hapus&id=<?php echo $rayon['id_rayon'] ?>" onClick="return confirm('Hapus data?')">Hapus</a></td>
                      		<td><a href="?menu=rayon&edit&id=<?php echo $rayon['id_rayon'] ?>">Edit</a></td>
            			</tr>
          				<?php $no++; } ?>
 					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>