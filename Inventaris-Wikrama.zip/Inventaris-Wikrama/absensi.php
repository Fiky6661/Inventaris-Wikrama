<div class="row">
	<div class="col-md-3">
		<div class="tile">
			<div class="tile-title">
				Absensi Siswa
			</div>
			<div class="tile-body">
				<div class="form-group">
					<label> Tanggal</label>
					<input class="form-control" id="demoDate" type="text" placeholder="Select Date">
				</div>
				<div class="form-group">
					<label >Rombel</label>
					 <select class="form-control" id="exampleSelect1">
                          <option>H</option>
                          <option>P</option>
                          
                        </select>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-9">
		<div class="tile">
			<div class="tile-title">
				Daftar Absensi Siswa
			</div>
			<div class="tile-body">
				<table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th rowspan="2">No</th>
                    <th rowspan="2">NIS</th>
                    <th rowspan="2">Nama </th>
                    <th colspan="4">Keterangan</th>
                    <th rowspan="2">Tanggal</th>
                  </tr>
                  <tr>	
					<th>H</th>
					<th>S</th>
					<th>I</th>
					<th>A</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
			</div>
		</div>
	</div>
</div>

