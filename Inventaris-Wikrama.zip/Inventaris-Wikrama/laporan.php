<form action="" method="post">
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <h4 class="tile-title">Laporan Detail Barang</h4>
                <hr>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="card text-center">
                <h5 class="card-title">Laporan Mingguan</h5><hr>
                <div class="card-body">
                    <a href="#minggu" class="btn btn-primary" data-toggle="modal">Look</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <h5 class="card-title">Laporan Barang Tata Boga</h5><hr>
                <div class="card-body">
                    <a href="" class="btn btn-primary">Look</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <h5 class="card-title">Laporan Barang Kantin</h5><hr>
                <div class="card-body">
                    <a href="" class="btn btn-primary">Look</a>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade model-wide" id="minggu">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Pilih Barang</h3>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <table class="table table-hover table-bordered" id="sampleTable">
                    <thead>
                        <tr>
                            <td>Kode Barang</td>
                            <td>Nama Barang</td>
                            <td>Satuan</td>
                            <td>Stok</td>
                        </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</form>