<?php 	
	$fun = new OOP();
	$tabel = "tb_barang";
	$tbl = "tb_peminjam";
	$id = $_GET['kd'];
	$kode 	= $fun->autokode("tb_pinjam","kd_pinjam","P");
	$kodee = $fun->selectWhere($tbl,"kd_peminjam",$id);
	$barangs   = $fun->select($tabel);
	$keranjang = $fun->selectdatas("tb_pinjam","status","0");

	if (isset($_GET['getItem'])) {
		$id = $_GET['id'];
		$dataS = $fun->selectWhere($tabel,"kd_barang",$id);
	}

	if(isset($_POST['simpan'])){
		$tambah = $fun -> selectWhere("tbl_pinjam","kd_barang",$_GET['id']);
		$barang = $_POST['kd_barang'];
		$sama = $tambah['kd_barang'];

		if($barang === $sama){
			$total = $_POST['stok'] + $tambah['jumlah'];
			$data -> $fun -> update("tbl_pinjam","jumlah = '$total'","kd_barang",$_GET['id'],"?page=pilih&kd=$_GET[kd]");
		}else{
			$kdPinjam = $_POST['kd_pinjam'];
		$kdPeminjaman = $_POST['kd_peminjaman'];
		$kd_barang = $_POST['kd_barang'];
		$nama = $_POST['nama_barang'];
		$kd_barang = $_POST['kd_barang'];
		$jumlah = $_POST['jumlah'];

		$table = "tb_pinjam";
		$redirect = "?page=pilih&kd=$_GET[kd]";
		$values = "'$kdPinjam','$kdPeminjaman','','$nama','$kd_barang','$jumlah'";

		$data = $fun->insert($table, $values, $redirect);
		}
	}

	if (isset($_POST['approve'])) {

		$tanggal = date('Y-m-d');

		foreach ($keranjang as $val) {
			$values = "status = 1";
			$redirect = "dashboard.php?page=peminjaman";
			$fun->update("tb_pinjam",$values,"status","0",$redirect);
		}


		// $sqlDelete = "TRUNCATE tb_pinjam";
		// mysqli_query($con,$sqlDelete);

		// echo $sqlDelete;

		// $delete = $fun->delete("tb_approve","kd_pinjam",$kode,$redirect);

	}

	if(isset($_GET['batal'])){
		$fun -> delete("tb_pinjam","kd_pinjam",$_GET['kp'],"?page=pilih&kd=$_GET[kd]");
	}
 ?>
<form method="post">
<div class="row">
		<div class="col-md-5">	
			<div class="tile" style="margin-top: 20px;">
				<h3 class="tile-title">Peminjaman</h3>
				<h5>Nama : <?php echo $kodee['nama']; ?> </h5><br>
				<div class="tile-body">	
					<div class="row">
						<div class="col-md-12">
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>Kode Peminjaman</label>
										<input type="text" name="kd_peminjaman" class="form-control" readonly="" required="" value="<?php echo @$_GET['kd'] ?>">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label>Kode Pinjam</label>
										<input type="text" name="kd_pinjam" class="form-control" readonly="" required="" value=" <?php echo $kode ?> ">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-8">
								<div class="form-group">
									<input type="text" class="form-control" name="kd_barang" readonly placeholder="Kode barang" value="<?php echo @$dataS['kd_barang'] ?>">
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
								<a class="btn btn-primary btn-block" href="#pilih" data-toggle="modal">Pilih Barang</a>
								</div>
							</div>
							</div>
							<div class="form-group">
								<label>Nama Barang</label>
								<input class="form-control" type="text" readonly autocomplete="off" name="nama_barang" value="<?= @$dataS['nama']  ?>">
							</div>
							<div class="form-group">
								<label>Stok</label>
								<input class="form-control" type="text" readonly="" autocomplete="off" name="stok" value="<?= @$dataS['b']  ?>">
							</div>

							<div class="form-group">
								<label>Jumlah Barang</label>
								<input type="Number"  name="jumlah" class="form-control" autocomplete="off" placeholder="Masukan Jumlah Barang" validate="">
							</div>
									<div class="tile-footer">
							            <button type="submit" class="btn btn-primary" name="simpan">Tambahkan ke Keranjang<i class="fa fa-plus"></i></button>
						        </div>		
							</div>
						</div>		
				</div>
			</div>
		</div>	
		<div class="col-md-7">
			<div class="tile" style="margin-top: 20px;">
				<h3 class="tile-title">Keranjang Pinjam</h3>
				<div class="tile-body">
					<div class="form-group">
						<button class="btn btn-primary" name="approve">Approved</button>
					</div>
					<div class="table-responsive">
						<table class="table table-striped table-bordered text-center">
							<tr>

								<th>Kode Pinjam</th>
								<th>Nama Barang</th>
								<th>Jumlah Pinjam</th>
								<th>Batal Pinjam</th>
							</tr>
							<tr>
								<?php $no = 1; 
									foreach ($keranjang as $jang) { ?>
								<td ><?= $jang['kd_pinjam']; ?></td>
								<td ><?= $jang['nama'] ?></td>
								<td ><?= $jang['jumlah'] ?></td>
								<td><a href="?page=pilih&kd=<?= $_GET['kd'] ?>&batal&kp=<?= $jang['kd_pinjam'] ?>" id="btdelete<?php echo $no; ?>" class="btn btn-primary " name="batal">Batal</a></td>

							</tr>
							<script>
							$("#btdelete<?php echo $no; ?>").click(function(){
								swal({
									title: "Hapus",
						            text: "Yakin Hapus?",
						            type: "warning",
						            showCancelButton: true,
						            confirmButtonText: "Yes",
						            cancelButtonText: "Cancel",
						      		closeOnConfirm: false,
						      		closeOnCancel: true
								},function(isConfirm){
									if (isConfirm) {
										window.location.href="?page=kasirTransaksi&delete&id=<?= $dd['kd_pretransaksi']; ?>";
									}
								})
							})
						</script>
						<?php $no++; } ?>
						</table>
					</div>
				</div>
			</div>
		</div>
</div>	
<div class="modal fade model-wide" id="pilih">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            	<h3>Pilih Barang</h3>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
            	<table class="table table-hover table-bordered" id="sampleTable">
            		<thead>
            			<tr>
            				<td>Kode Barang</td>
            				<td>Nama Barang</td>
            				<td>Satuan</td>
            				<td>Stok</td>
            			</tr>
            		</thead>
            		<tbody>
            			<?php foreach($barangs as $brg){ ?>
            			<tr>
            				<td><a href="dashboard.php?page=pilih&kd=KP002&getItem&id=<?php echo $brg['kd_barang'] ?>"><?php echo $brg['kd_barang'] ?></td>
            				<td><?php echo $brg['nama']; ?></td>
            				<td><?php echo $brg['satuan']; ?></td>
            				<td><?php echo $brg['b']; ?></td>
            			</tr>
            			<?php } ?>
            		</tbody>
            	</table>
            </div>
        </div>
    </div>
</div>
</form>