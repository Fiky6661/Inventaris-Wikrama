<?php 
  	$perintah = new CRUD();
  	$data = $perintah->select('tb_rombel');
  	$table = "tb_rombel";
  	$autokode = $perintah->autokode("tb_rombel","id_rombel","RM");
  	
  	if (isset($_POST['simpan'])) {
  		$rombel   = $perintah->validateHtml($_POST['rombel']);
  		if($rombel = " "){
  			$response = ['response'=>'negative','alert'=>'Lengkapi Field!'];
  		}else{
  			$value = "'$autokode','$rombel'";
  			$response = $perintah->insert($table,$value);
  		}
  	}


?>
<form method="post">
<div class="row">
	<div class="col-md-6">	
		<div class="tile">
			<h3 class="tile-title">Input Rombel</h3>
			<div class="tile-body">	
					<div class="form-group">
	                    <fieldset disabled="">
	                      <label class="control-label">ID Rombel</label>
	                      <input class="form-control" name="id_rombel" type="text" disabled="" value="<?php echo $autokode?>">
	                    </fieldset>
	                  </div>
					<div class="form-group">
						<label>Nama Rombel</label>
						<input type="text" name="rombel" class="form-control" placeholder="Masukkan Nama Rombel">
					</div>
					 <div class="tile-footer">
			            <button type="submit" class="btn btn-primary" name="simpan">Simpan <i class="fa fa-plus"></i></button>
			            <a class="btn btn-secondary" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Reset</a>
			        </div>
				
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="tile">
			<h3 class="tile-title">Data rombel</h3>
			<div class="tile-body">
				<table class="table table-hover table-bordered" id="sampleTable">
					<thead>
						<th>No.</th>
                    	<th>ID Rombel</th>
                    	<th>Nama Rombel</th>
                    	<th colspan="2">Aksi</th>
					</thead>
					<tbody>
						<?php 
            				$no = 1;
            				foreach ($data as $rombel) { ?>
            			<tr>
              				<td><?php echo $no; ?></td>
              				<td><?php echo $rombel['id_rombel'] ?></td>
              				<td><?php echo $rombel['rombel'] ?></td>
              				<td><a href="?menu=rombel&hapus&id=<?php echo $rombel['id_rombel'] ?>" onClick="return confirm('Hapus data?')">Hapus</a></td>
                      		<td><a href="?menu=rombel&edit&id=<?php echo $rombel['id_rombel'] ?>">Edit</a></td>
            			</tr>
          				<?php $no++; } ?>
 					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
</form>