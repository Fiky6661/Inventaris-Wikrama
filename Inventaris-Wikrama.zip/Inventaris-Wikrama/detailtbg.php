<div class="row">
	<div class="col-md-12">
		<div class="tile">
			<div class="tile-title">
				Detail Barang
			</div>
			<div class="tile-body">
				<div class="row">
					<div class="col-md-6">
						<b>Nama Barang</b>
						<p>test</p>
						<div class="divider"></div>
						<b>Kondisi</b>
						<p>Baik : </p>
						<p>Kurang baik : </p>
						<p>Rusak :</p>
						<p>Hilang : </p>
						<div class="divider"></div>
					</div>
					<div class="col-md-6">
						<b>Nama Barang</b>
						<p>test</p>
						<div class="divider"></div>
						<b>Kondisi</b>
						<p>Baik : </p>
						<p>Kurang baik : </p>
						<p>Rusak :</p>
						<p>Hilang : </p>
						<div class="divider"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>