<?php 


$datas = $fun->selectdatas("tb_barang","kd_milik","KM001");

if (isset($_GET['hapus'])) {
  $table = "tb_barang";
  $where = "kd_barang";
  $whereValues = $_GET['id'];
  $redirect = "?page=dtbg";
  $fun->delete($table,$where,$whereValues,$redirect);
}



 ?>
<form method="post">
<div class="app-title">
        <div>
          <h1><i class="fa fa-dropbox"></i> Data Tata Boga</h1>
          <p>Kumpulan data barang <b>Tata Boga</b></p>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Data barang</li>
          <li class="breadcrumb-item active"><a href="#">Data Barang Tata Boga</a></li>
        </ul>
      </div>      
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                <tr>
                  <th rowspan="2" class="text-center v-center">No</th>
                  <th rowspan="2" class="text-center v-center">Kode</th>
                  <th rowspan="2" class="text-center v-center">Nama</th>
                  <th colspan="4" class="text-center">Kondisi</th>
                  <th rowspan="2" class="text-center v-center">Suplier</th>
                  <th rowspan="2" class="text-center v-center">Tanggal</th>            
                  <th rowspan="2" colspan="3" class="text-center v-center">Aksi</th>

                </tr>
                <tr>
                  <th>B</th>
                  <th>RB</th>
                  <th>R</th>
                  <th>H</th>        
                </tr>
              </thead>
                <?php
                $no = 1;
                 foreach ($datas as $brng): ?>
                <tbody>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><?= $brng['kd_barang'] ?></td>
                  <td><?= $brng['nama'] ?></td> 
                  <td><?= $brng['b'] ?></td>
                  <td><?= $brng['rb'] ?></td>
                  <td><?= $brng['r'] ?></td>
                  <td><?= $brng['h'] ?></td>
                  <td><?= $brng['sumber'] ?></td>
                  <td><?= $brng['tanggal_masuk'] ?></td>
                  <td><a href="#myModal<?= $brng['id_barang'] ?>" data-toggle="modal" >Details</a></td>
                  <td><a href="?page=edit_barang&id=<?= $brng['id_barang'] ?>">Edit</a></td>
                  <td><a onclick = "return confirm('Hapus Ga?')" href="?page=dtbg&hapus&id=<?= $brng['kd_barang'] ?>" >Hapus</a></td>
                </tr>
                </tbody>
                <!-- modal details -->
                <div id="myModal<?= $brng['id_barang'] ?>" class="modal fade" role="dialog">
                <div class="modal-dialog">
                  <div class="modal-content modal-lg">
                    <div class="modal-header">
                      <h4 class="modal-title">Data Barang Tata Boga</h4>
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                      <div class="row"> 
                          <div class="col-md-6"> 
                              <b>Kode Barang</b>
                              <p><?= $brng['kd_barang'] ?></p>
                              <b>Nama Barang</b>
                              <p><?= $brng['nama'] ?></p>
                              <b>Tahun Perolehan Barang</b>
                              <p><?= $brng['tahun'] ?></p>
                              <b>Sumber Barang</b>
                              <p><?= $brng['sumber'] ?></p>
                              <b>Jumlah Barang</b>
                              <p><?= $brng['jumlah'] ?></p>
                              <b>Tempat Penyimpanan Barang</b>
                              <p><?= $brng['tempat'] ?></p>
                          </div>
                          <div class="col-md-6 text-left    ">
                            <b>Satuan Barang</b>
                              <p><?= $brng['satuan'] ?></p>
                              <b>Harga Satuan Barang</b>
                              <p><?= $brng['harga'] ?></p>
                            <b>Kondisi Barang</b>
                            <div class="row">
                              <div class="col-md-6">
                                <p><b>B  :</b><?= $brng['b'] ?></p>
                                <p><b>R  :</b><?= $brng['r'] ?></p>
                              </div>
                              <div class="col-md-6">
                                <p><b>RB :</b><?= $brng['rb'] ?></p>
                                <p><b>H  :</b><?= $brng['h'] ?></p>
                              </div>
                            </div>
                            <b>Keterangan</b>
                            <p><?= $brng['keterangan'] ?></p>
                            <b>Tanggal Masuk</b>
                            <p><?= $brng['tanggal_masuk'] ?></p>
                            
                          </div>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>
            <?php endforeach ?>
              <!-- modal details -->
              </table>
            </div>
          </div>
        </div>
      </div>
</form>
