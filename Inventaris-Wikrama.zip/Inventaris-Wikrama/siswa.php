<?php 
  include 'controller.php';
  $ks = new OOP();
  $data = $ks->select('query_siswa'); 

  if(isset($_POST['simpan'])){
    $nis = $_POST['nis'];
    $nama = $_POST['nama'];
    $jk = $_POST['jk'];
    $rayon = $_POST['rayon'];
    $rombel = $_POST['rombel'];
    $tgl_lahir = $_POST['tgl_lahir'];
  }

  if(isset($_GET['hapus'])){

  }

  if(isset($_GET['edit'])){
    
  }
  
 ?>

      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Input Siswa</h3>
            <div class="tile-body">
              <div class="row">
                <div class="col-md-8">
                  <form method="post">
                 <div class="form-group">
                  <label class="control-label">NIS</label>
                  <input class="form-control" type="text" name="nama" required placeholder="Masukkan NIS">
                </div>
                <div class="form-group">
                  <label class="control-label">Nama Lengkap</label>
                  <input class="form-control" type="text" name="nama" required placeholder="Masukkan Nama">
                </div>
                <label>Jenis Kelamin</label>
                <div class="form-group">
                  <label class="radio-inline">
                  <input type="radio" name="jk" value="L"
                    <?php if (isset($_GET['edit'])) {
                      if ($eData['jk'] == "L") {
                        echo "checked='on'";
                      }
                    } ?>
                  >Laki-laki
                  </label>
                  <label class="radio-inline">
                  <input type="radio" name="jk" value="P"
                    <?php if (isset($_GET['edit'])) {
                      if ($eData['jk'] == "P") {
                        echo "checked='on'";
                      }
                    } ?>
                  >Perempuan
                  </label>
                </div>  
                <div class="form-group">
                    <label for="exampleSelect1">Rayon</label>
                    <select class="form-control" name="rayon" id="exampleSelect1">
                      <?php  
                        $rayon = $ks->select("tb_rayon");
                        foreach ($rayon as $ry) { ?>
                          <option value="<?= $ry['id_rayon'] ?>">
                          <?php echo $ry['rayon']; ?>
                          </option>
                        <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="exampleSelect1">Rombel</label>
                    <select class="form-control" name="rombel" id="exampleSelect1">
                      <?php  
                        $rombel = $ks->select("tb_rombel");
                        foreach ($rombel as $rb) { ?>
                          <option value="<?= $rb['id_rombel'] ?>">
                          <?php echo $rb['rombel']; ?>
                          </option>
                      <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                  <label class="control-label">Tanggal Lahir</label>
                  <input class="form-control" name="tgl_lahir" type="date">
                </div>
            </div>
            <div class="col-md-4">
              <?php include './response.php'; ?>
            </div>    
            </div>
          </div>
              
                
            <div class="tile-footer">
              <a class="btn btn-primary" name="simpan" href="#" type="button"><i class="fa fa-fw fa-lg fa-check-circle"></i>Simpan</a>&nbsp;&nbsp;&nbsp;<a class="btn btn-secondary" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Reset</a>
            </div>
            </form>
          </div>
        </div>
        <div class="col-md-12">  
            <div class="tile">
            <h3 class="tile-title">Data Siswa</h3>
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>JK</th>
                    <th>Rayon</th>
                    <th>Rombel</th>
                    <th>Tanggal Lahir</th>
                    <th colspan="2">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
            $no = 1;
            foreach ($data as $siswa) { ?>
            <tr>
              <td><?php echo $no; ?></td>
              <td><?php echo $siswa['nis'] ?></td>
              <td><?php echo $siswa['nama'] ?></td>
              <td><?php echo $siswa['jk'] ?></td>
              <td><?php echo $siswa['rayon'] ?></td>
              <td><?php echo $siswa['rombel'] ?></td>
              <td><?php echo $siswa['tgl_lahir'] ?></td>
              <td><a href="?menu=siswa&hapus&nis=<?php echo $siswa['nis'] ?>" onClick="return confirm('Hapus data?')">Hapus</a></td>
                      <td><a href="?menu=siswa&edit&nis=<?php echo $siswa['nis'] ?>">Edit</a></td>
            </tr>
          <?php $no++; } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>