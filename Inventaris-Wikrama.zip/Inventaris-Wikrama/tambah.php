
<?php 
   $table = "tb_peminjam";
  $datas =  $fun->select($table);
  $kd = $fun->autokode($table,"kd_peminjam","KP");
  if (isset($_POST['tambah'])) {
    $table = "tb_peminjam";
    $nama = $_POST['nama'];
    $kode = $_POST['kd_peminjam'];
    $keterangan = $_POST['keterangan']; 
    $values = "'$kode','$nama','$keterangan'";
    $redirect = "?page=tambah";
    $fun->insert($table,$values,$redirect);
  }
  if (isset($_GET['hapus'])) {
    $table = "tb_peminjam";
    $where = "kd_peminjam";
    $whereValues = $_GET['id'];
    $redirect = "?page=tambah";
    $fun->delete($table,$where,$whereValues,$redirect);
    }
  if (isset($_GET['edit'])) {
  
  $whereValues = $_GET['id'];
  $where = "kd_peminjam";
  $redirect = "?page=tambah";
  $table = "tb_peminjam";
  $edit = $fun->edits($table,$where,$whereValues);
  $kd = $edit['kd_peminjam'];
  
  }

  if (isset($_POST['update'])) {
    $where = "kd_peminjam";
    $kode = $_POST['kd_peminjam'];
    $whereValues = $_POST['kd_peminjam'];
    $nama = $_POST['nama'];
    $ket = $_POST['keterangan'];
    $redirect = "?page=tambah";
    $table = "tb_peminjam";
    $values = "kd_peminjam = '$kode' , nama = '$nama' , keterangan = '$ket' ";

    $fun->update($table,$values,$where,$whereValues,$redirect);
  }

 ?>


    <form method="post">
			<div class="row">
				<div class="col-md-4">
					<div class="tile">
						<div class="tile-title">
							Tambah Peminjam
						</div>
						<div class="tile-body">
							<div class="row">
								<div class="col-md-12">
                                    <div class="form-group">
                                      <label>Kode Peminjam</label>
                                      <input type="text" name="kd_peminjam" class="form-control" required="" placeholder="Masukkan Kode Barang" value="<?=$kd ?>" readonly >
                                    </div>
                                    <div class="form-group">
                                      <label>Nama Peminjam</label>
                                      <input type="text" name="nama" class="form-control" required="" placeholder="Masukkan Nama Peminjam" value="<?= @$edit['nama']?>"  >
                                    </div>
                                    <div class="form-group">
                                      <label>Nama Barang</label>
                                      <textarea class="form-control" required="" placeholder="Masukkan Keterangan" name="keterangan"><?= @$edit['keterangan'] ?></textarea>
                                    </div>
									<?php if (isset($_GET['edit'])):?>
                  <button class="btn btn-danger" $disabled name="update">Update</button>
                  <a href="?page=tambah" class="btn btn-info" >Cancel</a>
                  <?php else: ?>
                    <button class="btn btn-danger" $disable name="tambah">Simpan</button>
                    <a href="?page=peminjaman" class="btn btn-info" >Transaksi</a>
                  <?php endif; ?>
                   
                  
								</div>
							</div>
						</div>
					</div>
        </div>
         <div class="col-md-8">
              <div class="tile">
                <div class="tile-title">
                  Data Peminjam
                </div>
                <div class="tile-body">
                  <table class="table table-hover table-bordered" id="sampleTable">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>KD Peminjam</th>
                        <th>Nama</th>
                        <th>Keterangan</th>
                        <th colspan="2">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php 
                      $no = 1;
                      foreach ($datas as $pinjam):?>
                      <tr>
                        <td><?= $no++ ?></td>
                        <td><?=$pinjam['kd_peminjam'] ?></td>
                        <td><?=$pinjam['nama'] ?></td>
                        <td><?=$pinjam['keterangan'] ?></td>
                        <td><a onclick = "return confirm('Hapus Ga?')" href="?page=tambah&hapus&id=<?= $pinjam['kd_peminjam'] ?>">Hapus</a></td>
                        <td><a href="?page=tambah&edit&id=<?=$pinjam['kd_peminjam'] ?>">Edit</a></td>

                      </tr>
                    <?php endforeach ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
				</form>